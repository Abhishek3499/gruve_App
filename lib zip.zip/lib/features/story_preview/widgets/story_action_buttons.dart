import 'package:flutter/material.dart';
import 'package:gruve_app/core/assets.dart';

class StoryActionButtons extends StatelessWidget {
  final bool isMuted;
  final VoidCallback onMuteToggle;
  final VoidCallback? onTextTap;
  final VoidCallback? onMusicTap;
  final VoidCallback? onFilterTap;
  final VoidCallback? onSpeedTap;
  final double currentSpeed;

  StoryActionButtons({
    super.key,
    required this.isMuted,
    required this.onMuteToggle,
    this.onTextTap,
    this.onMusicTap,
    this.onFilterTap,
    this.onSpeedTap,
    this.currentSpeed = 1.0,
  });

  final GlobalKey _moreKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        // VOLUME
        _buildActionButton(
          Icon(
            isMuted ? Icons.volume_off : Icons.volume_up,
            color: Colors.white,
          ),
          "Volume",
          size: 28,
          onTap: onMuteToggle,
        ),
        const SizedBox(width: 15),

        // TEXT (Aa)
        _buildActionButton(
          Image.asset(AppAssets.text, color: Colors.white),
          "Aa",
          size: 22,
          onTap: onTextTap,
        ),
        const SizedBox(width: 15),

        // MUSIC
        _buildActionButton(
          Image.asset(AppAssets.musics, color: Colors.white),
          "Music",
          size: 22,
          onTap: onMusicTap,
        ),
        const SizedBox(width: 15),

        // EFFECTS
        _buildActionButton(
          Image.asset(AppAssets.filter, color: Colors.white),
          "Effects",
          size: 22,
          onTap: onFilterTap,
        ),
        const SizedBox(width: 15),

        // SPEED (Video only)
        if (onSpeedTap != null) ...[
          _buildActionButton(
            const Icon(Icons.speed, color: Colors.white, size: 24),
            "Speed",
            size: 24,
            onTap: onSpeedTap,
          ),
          const SizedBox(width: 15),
        ],

        // MORE
        // _buildActionButton(
        //   Image.asset(AppAssets.extradots, color: Colors.white),
        //   "More",
        //   size: 22,
        //   key: _moreKey,
        //   onTap: () {
        //     final RenderBox renderBox =
        //         _moreKey.currentContext!.findRenderObject() as RenderBox;

        //     final position = renderBox.localToGlobal(Offset.zero);
        //     final size = renderBox.size;

        //     showMenu(
        //       context: context,
        //       position: RelativeRect.fromLTRB(
        //         position.dx,
        //         position.dy + size.height + 8,
        //         position.dx + size.width,
        //         0,
        //       ),
        //       color: const Color.fromARGB(255, 80, 33, 86),
        //       shape: RoundedRectangleBorder(
        //         borderRadius: BorderRadius.circular(16),
        //       ),
        //       items: [
        //         _popupItem(AppAssets.draw, 'Draw'),
        //         _popupItem(AppAssets.saves, 'Save'),
        //         _popupItem(AppAssets.turnoff, 'Turn off commenting'),
        //       ],
        //     );
        //   },
        // ),
      ],
    );
  }

  Widget _buildActionButton(
    Widget icon,
    String tooltip, {
    double size = 18,
    VoidCallback? onTap,
    Key? key,
  }) {
    return Tooltip(
      message: tooltip,
      child: GestureDetector(
        key: key,
        onTap: onTap,
        child: Container(
          width: 40,
          height: 40,
          alignment: Alignment.center,
          decoration: const BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.white24,
          ),
          child: SizedBox(width: size, height: size, child: icon),
        ),
      ),
    );
  }

  PopupMenuItem _popupItem(String assetPath, String text) {
    return PopupMenuItem(
      height: 35,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Row(
        children: [
          Image.asset(assetPath, color: Colors.white, width: 18, height: 18),
          const SizedBox(width: 8),
          Text(text, style: const TextStyle(color: Colors.white, fontSize: 14)),
        ],
      ),
    );
  }
}
