import 'package:flutter/material.dart';
import 'package:gruve_app/core/constants/app_colors.dart';
import 'package:gruve_app/features/highlights/controller/highlight_controller.dart';
import 'package:gruve_app/features/highlights/controller/highlight_state_manager.dart';
import 'package:gruve_app/features/highlights/model/highlight_model.dart';
import 'package:gruve_app/features/highlights/provider/highlight_flow_provider.dart';
import 'package:gruve_app/features/highlights_create/controller/highlight_create_controller.dart';
import 'package:gruve_app/features/story_preview/api/story_api/controller/story_state_controller.dart';
import 'package:gruve_app/features/story_preview/controllers/story_playback_controller.dart';
import 'package:gruve_app/features/story_preview/widgets/story_view_topbar/story_selector_screen.dart';
import 'package:provider/provider.dart';
import 'package:gruve_app/core/utils/app_logger.dart';
import 'package:gruve_app/core/widgets/app_cached_image.dart';
import 'package:gruve_app/features/home/post_share_flow_bridge.dart';

void _log(String message) {
  AppLogger.d(message);
  
}

void showInstagramHighlightSheet(BuildContext context) {
  final playbackController = StoryPlaybackController();
  final storyStateController = context.read<StoryStateController>();
  final highlightController = context.read<HighlightController>();

  _log('[HighlightSheet] Opening sheet -> Pause Story');

  final currentStory = storyStateController.currentStory;
  _log(
    '[HighlightSheet] Current story when opening sheet: '
    '${currentStory?.id ?? 'NULL'}',
  );

  if (currentStory == null) {
    _log('[HighlightSheet] ERROR: cannot open sheet without currentStory');
    return;
  }

  if (currentStory.id.isEmpty) {
    _log('[HighlightSheet] ERROR: cannot open sheet with empty story id');
    return;
  }

  playbackController.pauseStory(reason: 'Highlight Sheet Open');

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (context) => const HighlightSheetContent(),
  ).then((_) {
    _log('[HighlightSheet] Sheet closed -> Resume Story');
    playbackController.resumeStory(reason: 'Highlight Sheet Closed');

    highlightController.fetchMyHighlights();
  });
}

class HighlightSheetContent extends StatefulWidget {
  const HighlightSheetContent({super.key});

  @override
  State<HighlightSheetContent> createState() => _HighlightSheetContentState();
}

class _HighlightSheetContentState extends State<HighlightSheetContent> {
  int selectedIndex = -1;
  bool _isLoadingHighlights = true;

  late final HighlightController _highlightController;
  late final HighlightCreateController _createController;
  late final HighlightStateManager _highlightStateManager;
  late final StoryStateController _storyStateController;

  @override
  void initState() {
    super.initState();
    _storyStateController = context.read<StoryStateController>();
    _highlightController = context.read<HighlightController>();
    _createController = context.read<HighlightCreateController>();
    _highlightStateManager = context.read<HighlightStateManager>();
    _log('[HighlightSheet] initState - Fetching highlights');

    final currentStory = _storyStateController.currentStory;
    _log(
      '[HighlightSheet] Current story on init: ${currentStory?.id ?? 'NULL'}',
    );

    _fetchHighlights();
  }

  Future<void> _fetchHighlights() async {
    setState(() => _isLoadingHighlights = true);

    await _highlightController.fetchMyHighlights();

    if (!mounted) return;
    setState(() => _isLoadingHighlights = false);
  }

  bool _isStoryAlreadyAdded(HighlightModel highlight) {
    final currentStory = _storyStateController.currentStory;
    if (currentStory == null || currentStory.id.isEmpty) return false;
    return highlight.containsStory(currentStory.id);
  }

  bool _isSelectedStoryAlreadyAdded() {
    if (selectedIndex < 0 ||
        selectedIndex >= _highlightController.highlights.length) {
      return false;
    }

    return _isStoryAlreadyAdded(_highlightController.highlights[selectedIndex]);
  }

  Future<void> _handleDonePressed() async {
    final flowProvider = context.read<HighlightFlowProvider>();

    if (flowProvider.isProcessing) return;

    final scaffoldMessenger = ScaffoldMessenger.of(context);
    final sheetNavigator = Navigator.of(context);
    final rootNavigator = Navigator.of(context, rootNavigator: true);

    flowProvider.setProcessing(true);

    final currentStory = _storyStateController.currentStory;
    final highlight =
        selectedIndex >= 0 &&
            selectedIndex < _highlightController.highlights.length
        ? _highlightController.highlights[selectedIndex]
        : null;

    _log('[Flow] Start Add to Highlight');
    _log('[Flow] Story ID: ${currentStory?.id}');
    _log('[Flow] Highlight ID: ${highlight?.id}');

    try {
      if (currentStory == null) {
        _log('[Flow] ERROR: currentStory is null');
        return;
      }

      if (currentStory.id.isEmpty) {
        _log('[HighlightSheet] ERROR: currentStory.id is empty');
        return;
      }

      if (highlight == null) {
        _log(
          '[HighlightSheet] Invalid index: $selectedIndex, highlights count: '
          '${_highlightController.highlights.length}',
        );
        return;
      }

      await _createController.addStoryToHighlight(
        highlightId: highlight.id,
        storyId: currentStory.id,
      );

      if (_createController.isSuccess) {
        _log('[Flow] API SUCCESS');

        await _highlightStateManager.addHighlightedStory(currentStory.id);

        if (!mounted) return;

        sheetNavigator.pop();

        _log('[Flow] Navigation triggered');
        PostShareFlowBridge.onRequestShowProfileTab?.call();
        rootNavigator.pop();
      } else {
        _log('[Flow] API FAILED');
        if (mounted && _createController.message.isNotEmpty) {
          scaffoldMessenger.showSnackBar(
            SnackBar(content: Text(_createController.message)),
          );
        }
      }
    } finally {
      flowProvider.setProcessing(false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final flowProvider = context.watch<HighlightFlowProvider>();

    return Stack(
      children: [
        Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                margin: const EdgeInsets.only(top: 12, bottom: 8),
                height: 4,
                width: 40,
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 16),
                child: Text(
                  'Add to highlights',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
              SizedBox(
                height: 250,
                child: _isLoadingHighlights
                    ? const Center(
                        child: SizedBox(
                          width: 28,
                          height: 28,
                          child: CircularProgressIndicator(
                            color: AppColors.loaderPrimary,
                            strokeWidth: 2.4,
                          ),
                        ),
                      )
                    : _buildHighlightsList(),
              ),
              AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                height: selectedIndex != -1 ? 80 : 30,
                child: selectedIndex != -1
                    ? Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue,
                            minimumSize: const Size(double.infinity, 50),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          onPressed: _isSelectedStoryAlreadyAdded()
                              ? null
                              : _handleDonePressed,
                          child: Text(
                            _isSelectedStoryAlreadyAdded()
                                ? 'Already added'
                                : 'Done',
                            style: const TextStyle(color: Colors.white),
                          ),
                        ),
                      )
                    : const SizedBox.shrink(),
              ),
            ],
          ),
        ),
        if (flowProvider.isProcessing)
          Positioned.fill(
            child: Container(
              color: Colors.black.withValues(alpha: 0.4),
              child: const Center(
                child: SizedBox(
                  width: 28,
                  height: 28,
                  child: CircularProgressIndicator(
                    color: AppColors.loaderDark,
                    strokeWidth: 2.4,
                  ),
                ),
               ),
            ),
          ),
      ],
    );
  }

  Widget _buildHighlightsList() {
    final highlights = _highlightController.highlights;

    return ListView.builder(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: highlights.length + 1,
      itemBuilder: (context, index) {
        if (index == 0) {
          return _buildAddButton();
        }

        final highlightIndex = index - 1;
        final highlight = highlights[highlightIndex];
        final isSelected = selectedIndex == highlightIndex;
        final isAlreadyAdded = _isStoryAlreadyAdded(highlight);

        return GestureDetector(
          onTap: () {
            if (isAlreadyAdded) {
              _log(
                '[HighlightSheet] Duplicate detected: '
                'highlight_id=${highlight.id}, '
                'story_id=${_storyStateController.currentStory?.id}',
              );
              ScaffoldMessenger.of(
                context,
              ).showSnackBar(const SnackBar(content: Text('Already added')));
            }

            _log('[HighlightSheet] Highlight tapped - selection only');
            setState(() {
              selectedIndex = isSelected ? -1 : highlightIndex;
            });
          },
          child: _buildHighlightThumbnail(highlight, isSelected),
        );
      },
    );
  }

  Widget _buildAddButton() {
    return Padding(
      padding: const EdgeInsets.only(right: 12.0),
      child: Column(
        children: [
          InkWell(
            onTap: () async {
              _log('[HighlightSheet] Navigating to CreateHighlightSheet');

              final currentStory = _storyStateController.currentStory;

              if (currentStory == null) {
                _log('[HighlightSheet] ERROR: No story selected');
                return;
              }

              if (currentStory.id.isEmpty) {
                _log('[HighlightSheet] ERROR: currentStory.id is empty');
                return;
              }

              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => CreateHighlightSheet(
                    storyImageUrl: currentStory.mediaUrl,
                    storyId: currentStory.id,
                  ),
                ),
              );
            },
            borderRadius: BorderRadius.circular(20),
            child: Container(
              height: 180,
              width: 130,
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.grey[300]!, width: 1),
              ),
              child: const Icon(Icons.add, size: 40, color: Colors.black54),
            ),
          ),
          const SizedBox(height: 10),
          const Text(
            'New',
            style: TextStyle(fontSize: 14, color: Colors.black54),
          ),
        ],
      ),
    );
  }

  Widget _buildHighlightThumbnail(HighlightModel highlight, bool isSelected) {
    return Padding(
      padding: const EdgeInsets.only(right: 12.0),
      child: Column(
        children: [
          AnimatedScale(
            scale: isSelected ? 0.95 : 1.0,
            duration: const Duration(milliseconds: 200),
            child: Stack(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Container(
                    height: 180,
                    width: 130,
                    color: Colors.grey[300],
                    child: highlight.coverMediaUrl.isNotEmpty
                        ? AppCachedImage(
                            imageUrl: highlight.coverMediaUrl,
                            fit: BoxFit.cover,
                          )
                        : const Icon(Icons.collections),
                  ),
                ),
                AnimatedOpacity(
                  duration: const Duration(milliseconds: 200),
                  opacity: isSelected ? 1.0 : 0.0,
                  child: Container(
                    height: 180,
                    width: 130,
                    decoration: BoxDecoration(
                      color: Colors.black26,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.blue, width: 3),
                    ),
                    child: const Icon(Icons.check_circle, color: Colors.blue),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Text(highlight.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }
}
