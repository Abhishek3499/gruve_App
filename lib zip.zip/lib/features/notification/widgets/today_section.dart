import 'package:flutter/material.dart';
import 'package:gruve_app/features/notification/api/models/notification_model.dart';
import 'package:gruve_app/features/notification/providers/notification_provider.dart';
import 'package:provider/provider.dart';
import 'notification_tile.dart';
import 'follow_tile.dart';

class TodaySection extends StatelessWidget {
  final List<AppNotification> notifications;

  const TodaySection({super.key, required this.notifications});

  @override
  Widget build(BuildContext context) {
    final provider = context.read<NotificationProvider>();

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(22, 18, 24, 42),
      color: Colors.transparent,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Today",
            style: TextStyle(
              color: Colors.white,
              fontSize: 13,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 14),
          ...notifications.map((n) {
            final actorUsername = n.actor?.username ?? 'Someone';
            final profilePic = n.actor?.profilePicture ?? '';
            final timeDisplay = NotificationProvider.formatTime(n.createdAt);

            if (n.type == 'follow' || n.type == 'user_follow') {
              return FollowTile(
                username: actorUsername,
                time: timeDisplay,
                profileImage: profilePic,
                userId: n.actor?.id ?? '',
                isRead: n.isRead,
                onTap: () => provider.markNotificationAsRead(n.id),
              );
            } else {
              String msg = 'interacted with your post.';
              if (n.type == 'post_like' || n.type == 'like') {
                msg = 'liked your video.';
              } else if (n.type == 'comment' || n.type == 'post_comment') {
                msg = 'commented on your video.';
              } else if (n.type == 'comment_mention') {
                msg = 'mentioned you in a comment.';
              }
              return NotificationTile(
                username: actorUsername,
                message: msg,
                time: timeDisplay,
                profileImage: profilePic,
                isRead: n.isRead,
                onTap: () => provider.markNotificationAsRead(n.id),
              );
            }
          }),
        ],
      ),
    );
  }
}
