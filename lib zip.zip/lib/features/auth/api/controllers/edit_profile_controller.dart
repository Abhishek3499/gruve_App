import 'package:gruve_app/features/auth/api/services/edit_profile_service.dart';
import 'package:gruve_app/features/auth/validators/signup_validator.dart';

import '../models/edit_profile_request.dart';
import '../models/edit_profile_response.dart';

class EditProfileController {
  final EditProfileService _service = EditProfileService();
  bool isLoading = false;
  bool isUpdating = false;
  String? errorMessage;
  EditProfileResponse? profileResponse;

  /// Fetch user profile data from API
  Future<void> fetchProfile() async {
    isLoading = true;
    errorMessage = null;
    profileResponse = null;

    try {
      final result = await _service.fetchProfile();
      profileResponse = result;
    } catch (e) {
      profileResponse = null;
      errorMessage = e.toString().replaceFirst('Exception: ', '');
    }

    isLoading = false;
  }

  /// Update user profile data
  Future<void> updateProfile({
    required String fullname,
    required String username,
    String? bio,
    // ignore: non_constant_identifier_names
    String? profile_picture,
  }) async {
    isUpdating = true;
    errorMessage = null;
    try {
      final result = await _service.updateProfile(
        request: EditProfileRequest(
          fullname: fullname,
          username: username,
          bio: bio,
          profilePicture: profile_picture,
        ),
      );

      profileResponse = result;
    } catch (e) {
      errorMessage = e.toString().replaceFirst('Exception: ', '');
    }

    isUpdating = false;
  }

  /// Check if email should be shown
  bool get showEmail =>
      profileResponse?.data.email != null &&
      profileResponse!.data.email!.isNotEmpty;

  /// Check if phone should be shown
  bool get showPhone =>
      profileResponse?.data.phone != null &&
      profileResponse!.data.phone!.isNotEmpty;

  /// Check if bio should be shown
  bool get showBio =>
      profileResponse?.data.bio != null &&
      profileResponse!.data.bio!.isNotEmpty;

  /// Get current profile picture URL or fallback
  String get currentProfilePicture {
    if (profileResponse?.data.profilePicture != null &&
        profileResponse!.data.profilePicture!.isNotEmpty) {
      return profileResponse!.data.profilePicture!;
    }
    return 'assets/search_screen_images/profile.png'; // Default fallback
  }

  /// Get profile data for form population
  String get username => profileResponse?.data.username ?? '';
  String get fullName => profileResponse?.data.fullName ?? '';
  String get email => profileResponse?.data.email ?? '';
  String get phone => profileResponse?.data.phone ?? '';
  String get gender => profileResponse?.data.gender ?? '';
  String get bio => profileResponse?.data.bio ?? '';

  /// Validate form data
  String? validateForm({
    required String fullName,
    required String username,
    String? bio,
  }) {
    final nameError = SignupValidator.validateFullNameRealTime(fullName);
    if (nameError != null) return nameError;

    final usernameError = SignupValidator.validateUsernameRealTime(username);
    if (usernameError != null) return usernameError;

    if (bio != null) {
      final bioError = SignupValidator.validateBioRealTime(bio);
      if (bioError != null) return bioError;
    }

    return null;
  }

  /// Clear error message
  void clearError() {
    errorMessage = null;
  }
}
