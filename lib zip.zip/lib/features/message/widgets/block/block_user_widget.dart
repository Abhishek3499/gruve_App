import 'package:flutter/material.dart';
import 'package:gruve_app/features/user_profile/providers/block_provider.dart';
import 'package:provider/provider.dart';

class BlockUserWidget extends StatefulWidget {
  final String name;
  final String username;
  final String userId;
  final bool isBlocked;

  const BlockUserWidget({
    super.key,
    required this.name,
    required this.username,
    required this.userId,
    this.isBlocked = false,
  });

  @override
  State<BlockUserWidget> createState() => _BlockUserWidgetState();
}

class _BlockUserWidgetState extends State<BlockUserWidget> {
  bool _isLoading = false;

  Future<void> _handleToggleBlock() async {
    if (_isLoading) return;
    setState(() => _isLoading = true);

    try {
      final blockProvider = context.read<BlockProvider>();
      await blockProvider.toggleBlockUser(
        widget.userId,
        refreshList: true,
        optimistic: false,
      );
      if (!mounted) return;

      Navigator.of(context).pop(blockProvider.isBlocked(widget.userId));
    } catch (_) {
      if (!mounted) return;
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !_isLoading,
      child: Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: Stack(
          clipBehavior: Clip.none,
          alignment: Alignment.topCenter,
          children: [
            /// MAIN CARD
            Container(
              margin: const EdgeInsets.only(top: 30),
              child: ClipPath(
                clipper: TopCurveClipper(),
                child: Container(
                  padding: const EdgeInsets.fromLTRB(24, 55, 24, 28),
                  color: const Color(0xFF5A1E67),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const SizedBox(height: 20),

                      Text(
                        "${widget.isBlocked ? 'Unblock' : 'Block'} ${widget.name}",
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w600,
                        ),
                      ),

                      const SizedBox(height: 9),

                      Text(
                        "(${widget.username}) ?",
                        style: const TextStyle(
                          color: Color(0xFFD9C7E0),
                          fontSize: 14,
                        ),
                      ),

                      const SizedBox(height: 19),

                      Text(
                        widget.isBlocked
                            ? "You will be able to message each other again after unblocking."
                            : "They will not be able to message you or see this chat.",
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 13,
                        ),
                      ),

                      const SizedBox(height: 27),

                      /// YES BUTTON
                      GestureDetector(
                        onTap: _isLoading ? null : _handleToggleBlock,
                        behavior: HitTestBehavior.opaque,
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(30),
                            gradient: const LinearGradient(
                              colors: [Color(0xFF8E2DE2), Color(0xFF72008D)],
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.purpleAccent.withValues(
                                  alpha: 0.6,
                                ),
                                blurRadius: 20,
                                offset: const Offset(0, 10),
                              ),
                            ],
                          ),
                          child: Center(
                            child: _isLoading
                                ? const SizedBox(
                                    height: 20,
                                    width: 20,
                                    child: CircularProgressIndicator(
                                      color: Colors.white,
                                      strokeWidth: 2,
                                    ),
                                  )
                                : const Text(
                                    "Yes",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            /// FLOATING CLOSE BUTTON
            Positioned(
              top: 53,
              child: GestureDetector(
                onTap: _isLoading ? null : () => Navigator.pop(context),
                child: Container(
                  height: 50,
                  width: 50,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [Color(0xFF8E2DE2), Color(0xFF72008D)],
                    ),
                  ),
                  child: const Icon(Icons.close, color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class TopCurveClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    const double radius = 30.0;
    const double bumpHeight = 35.0; // card ka top offset
    const double bumpWidth = 51.0; // curve width - chota
    const double bumpUp = 22.0; // kitna upar jayega - subtle

    double center = size.width / 2;

    final Path path = Path();

    path.moveTo(radius, bumpHeight);
    path.lineTo(center - bumpWidth, bumpHeight);

    // Subtle bump UP
    path.cubicTo(
      center - bumpWidth + 10,
      bumpHeight,
      center - 18,
      bumpHeight - bumpUp,
      center,
      bumpHeight - bumpUp,
    );
    path.cubicTo(
      center + 18,
      bumpHeight - bumpUp,
      center + bumpWidth - 10,
      bumpHeight,
      center + bumpWidth,
      bumpHeight,
    );

    // Top-right corner
    path.lineTo(size.width - radius, bumpHeight);
    path.quadraticBezierTo(
      size.width,
      bumpHeight,
      size.width,
      bumpHeight + radius,
    );

    // Right side
    path.lineTo(size.width, size.height - radius);
    path.quadraticBezierTo(
      size.width,
      size.height,
      size.width - radius,
      size.height,
    );

    // Bottom
    path.lineTo(radius, size.height);
    path.quadraticBezierTo(0, size.height, 0, size.height - radius);

    // Left side
    path.lineTo(0, bumpHeight + radius);
    path.quadraticBezierTo(0, bumpHeight, radius, bumpHeight);

    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}
