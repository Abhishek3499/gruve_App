import 'package:flutter/material.dart';
import 'package:gruve_app/features/profile_menu_drawer/widgets/Helpcenter/help_center_header.dart';
import 'package:gruve_app/features/profile_menu_drawer/widgets/Helpcenter/help_center_switcher_tab.dart';
import 'package:gruve_app/features/profile_menu_drawer/widgets/Helpcenter/faq_tab.dart';
import 'package:gruve_app/features/profile_menu_drawer/widgets/Helpcenter/contact_us_tab.dart';
import 'package:gruve_app/features/profile_menu_drawer/models/help_center_tab.dart';

class HelpCenterScreen extends StatefulWidget {
  const HelpCenterScreen({super.key});

  @override
  State<HelpCenterScreen> createState() => _HelpCenterScreenState();
}

class _HelpCenterScreenState extends State<HelpCenterScreen> {
  HelpCenterTab selectedTab = HelpCenterTab.faq;

  void _onTabChanged(HelpCenterTab tab) {
    setState(() {
      selectedTab = tab;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Container(
        width: double.infinity,
        height: double.infinity, // Poori screen cover karne ke liye
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter, // Gradient kahan se shuru hoga
            end: Alignment.bottomCenter, // Kahan khatam hoga
            colors: [
              Color.fromARGB(255, 57, 3, 69), // Dark Purple
              Color.fromARGB(255, 3, 0, 4), // Near Black
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              const HelpCenterHeader(),
              const SizedBox(height: 10),
              HelpCenterSwitcherTab(
                selectedTab: selectedTab,
                onTabChanged: _onTabChanged,
              ),
              const SizedBox(height: 20),

              /// CONTENT AREA
              Expanded(
                child: selectedTab == HelpCenterTab.faq
                    ? const FaqTab()
                    : const ContactUsTab(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
