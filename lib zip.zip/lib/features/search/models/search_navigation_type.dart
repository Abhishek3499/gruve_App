enum SearchNavigationType {
  profile,
  chat,
}
