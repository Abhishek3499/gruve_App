import 'package:flutter/material.dart';
import 'package:gruve_app/core/assets.dart';

/// Personal information card with editable profile fields
class PersonalInfoCard extends StatelessWidget {
  final TextEditingController nameController;
  final TextEditingController phoneController;
  final TextEditingController emailController;
  final TextEditingController usernameController;
  final TextEditingController genderController;
  final TextEditingController bioController;
  final VoidCallback onSave;
  final bool showEditIcon;
  final bool showUpdateButton;
  final bool isReadOnly;
  final bool showEmail;
  final bool showPhone;
  final bool isUpdating;

  final FocusNode? nameFocusNode;
  final FocusNode? usernameFocusNode;
  final FocusNode? bioFocusNode;

  const PersonalInfoCard({
    super.key,
    required this.nameController,
    required this.phoneController,
    required this.emailController,
    required this.usernameController,
    required this.genderController,
    required this.bioController,
    required this.onSave,
    this.showEditIcon = true,
    this.showUpdateButton = true,
    this.isReadOnly = false,
    this.showEmail = true,
    this.showPhone = true,
    this.isUpdating = false,
    this.nameFocusNode,
    this.usernameFocusNode,
    this.bioFocusNode,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: 320,

        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(25),
          border: Border.all(color: const Color(0xFF9485EA), width: 0.3),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 05),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              _buildHeader(),
              const SizedBox(height: 24),

              _buildField(
                "Full Name",
                nameController,
                focusNode: nameFocusNode,
              ),
              _divider(),

              // Show phone field only if showPhone is true
              if (showPhone) ...[
                _buildField("Phone", phoneController, forceReadOnly: true),
                _divider(),
              ],

              // Show email field only if showEmail is true
              if (showEmail) ...[
                _buildField("Email", emailController, forceReadOnly: true),
                _divider(),
              ],

              _buildField(
                "Username",
                usernameController,
                focusNode: usernameFocusNode,
              ),
              _divider(),

              _buildField("Gender", genderController, forceReadOnly: true),
              _divider(),

              _buildField(
                "Bio",
                bioController,
                isBio: true,
                focusNode: bioFocusNode,
              ),

              // Show update button only if showUpdateButton is true
              if (showUpdateButton) ...[
                const SizedBox(height: 20),
                _buildUpdateButton(),
                const SizedBox(height: 10),
              ],
            ],
          ),
        ),
      ),
    );
  }

  /// 🔥 Header with conditional edit icon
  Widget _buildHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        const Text(
          "Personal Info",
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
        // Show edit icon only if showEditIcon is true
        if (showEditIcon)
          Container(
            padding: const EdgeInsets.all(6),

            child: Image.asset(AppAssets.editpro, width: 22, height: 22),
          ),
      ],
    );
  }

  /// 🔥 Field (Read-only or Editable)
  Widget _buildField(
    String label,
    TextEditingController controller, {
    bool isBio = false,
    bool forceReadOnly = false,
    FocusNode? focusNode,
  }) {
    final bool fieldReadOnly = isReadOnly || forceReadOnly;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 6),
        TextField(
          controller: controller,
          focusNode: focusNode,
          scrollPadding: EdgeInsets.zero,
          enabled: !fieldReadOnly, // ✅ Read-only mode
          readOnly: fieldReadOnly, // ✅ Read-only mode
          maxLines: isBio ? 3 : 1,
          maxLength: isBio ? 150 : null,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 14,
            fontWeight: FontWeight.w500,
          ),
          decoration: const InputDecoration(
            isDense: true,
            contentPadding: EdgeInsets.zero,
            border: InputBorder.none,
            enabledBorder: InputBorder.none,
            disabledBorder: InputBorder.none,
            focusedBorder: InputBorder.none,
            counterText: '',
          ),
        ),
      ],
    );
  }

  Widget _divider() {
    return Container(
      height: 0.5,
      margin: const EdgeInsets.symmetric(vertical: 6),
      color: Colors.white.withValues(alpha: 0.2),
    );
  }

  Widget _buildUpdateButton() {
    return Container(
      width: double.infinity,
      height: 48,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        color: const Color(0xFF72008D),
      ),

      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(30),
          onTap: isUpdating ? null : onSave,
          child: Center(
            child: isUpdating
                ? const SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor: AlwaysStoppedAnimation<Color>(
                        Color(0xFFBB86FC),
                      ),
                    ),
                  )
                : const Text(
                    "Update",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
          ),
        ),
      ),
    );
  }
}
