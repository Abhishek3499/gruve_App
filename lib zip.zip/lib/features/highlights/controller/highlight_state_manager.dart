import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:gruve_app/core/utils/app_logger.dart';

/// Global state manager for tracking which stories are added to highlights
/// This is needed because the API doesn't provide stories data in highlights response
class HighlightStateManager extends ChangeNotifier {
  static const String _highlightedStoriesKey = 'highlighted_story_ids';

  final Set<String> _highlightedStoryIds = <String>{};

  /// Get all highlighted story IDs
  Set<String> get highlightedStoryIds => _highlightedStoryIds.toSet();

  /// Check if a specific story is highlighted
  bool isStoryHighlighted(String storyId) {
    return _highlightedStoryIds.contains(storyId);
  }

  /// Mark a story as highlighted
  Future<void> markStoryAsHighlighted(String storyId) async {
    if (storyId.isNotEmpty) {
      _highlightedStoryIds.add(storyId);
      await _saveToPreferences();
      notifyListeners();
      AppLogger.d(
        '[HighlightStateManager] Story $storyId marked as highlighted',
      );
    }
  }

  /// Add highlighted story (alias for consistency)
  Future<void> addHighlightedStory(String storyId) async {
    await markStoryAsHighlighted(storyId);
  }

  /// Remove a story from highlighted list (if needed)
  Future<void> removeStoryFromHighlighted(String storyId) async {
    _highlightedStoryIds.remove(storyId);
    await _saveToPreferences();
    notifyListeners();
    AppLogger.d(
      '[HighlightStateManager] Story $storyId removed from highlighted list',
    );
  }

  /// Clear all highlighted stories (for logout/reset)
  Future<void> clearAllHighlightedStories() async {
    _highlightedStoryIds.clear();
    await _saveToPreferences();
    notifyListeners();
    AppLogger.d('[HighlightStateManager] All highlighted stories cleared');
  }

  /// Save highlighted story IDs to SharedPreferences
  Future<void> _saveToPreferences() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final storyIdsList = _highlightedStoryIds.toList();
      await prefs.setStringList(_highlightedStoriesKey, storyIdsList);
      AppLogger.d(
        '[HighlightStateManager] Saved ${storyIdsList.length} highlighted stories to preferences',
      );
    } catch (e) {
      AppLogger.d('[HighlightStateManager] Error saving to preferences: $e');
    }
  }

  /// Load highlighted story IDs from SharedPreferences
  Future<void> loadFromPreferences() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final storyIdsList = prefs.getStringList(_highlightedStoriesKey) ?? [];
      _highlightedStoryIds
        ..clear()
        ..addAll(storyIdsList);
      notifyListeners();
      AppLogger.d(
        '[HighlightStateManager] Loaded ${storyIdsList.length} highlighted stories from preferences',
      );
    } catch (e) {
      AppLogger.d('[HighlightStateManager] Error loading from preferences: $e');
    }
  }
}
