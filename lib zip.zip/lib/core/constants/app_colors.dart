import 'package:flutter/material.dart';

class AppColors {
  // Main Gradient
  static const Color gradientTop = Color(0xFF33123B);
  static const Color gradientBottom = Color(0xFF511263);

  // Profile Screen Gradient
  static const Color profileGradientTop = Color(0xFF7D63D1);
  static const Color profileGradientBottom = Color(0xFF212235);

  // Section Colors
  static const Color todaySection = Color(0xFF33123B);
  static const Color newSection = Color(0xFF833FB0);
  static const Color thisWeekSection = Color(0xFF511263);
  static const Color bottomBlack = Color(0xFF000000);

  // Views Screen Colors
  static const Color viewsGradientLeft = Color(0xFFFF3AFF);
  static const Color viewsGradientRight = Color(0xFF72008D);
  static const Color donutHighlight = Color(0xFFFF3AFF);
  static const Color donutBackground = Color(0xFF72008D);

  // White Shades
  static const Color white = Colors.white;
  static const Color white70 = Color(0xB3FFFFFF);
  static const Color white24 = Color(0x3DFFFFFF);

  // Profile Colors
  static const Color pink = Color(0xFFFF69B4);

  // Notification Colors
  static const Color notificationBg = Color(0xFF33123B);
  static const Color notificationTile = Color(0xFF33123B);

  // Edit Profile Colors
  static const Color primary = Color(0xFF9C27B0);
  static const Color background = Color(0xFFF5F5F5);
  static const Color textPrimary = Color(0xFF212121);
  static const Color textSecondary = Color(0xFF757575);
  static const Color error = Color(0xFFE53935);
  static const Color success = Color(0xFF4CAF50);
  static const Color green = Colors.green;
  static const Color transparent = Colors.transparent;

  // ============ LOADER COLORS ============
  /// Primary loader color - used for circular progress indicators
  static const Color loaderPrimary = Color(0xFF9544A7);

  /// Dark loader color - used on dark backgrounds
  static const Color loaderDark = Color(0xFFBB86FC);

  /// Light loader color - used on light backgrounds
  static const Color loaderLight = Colors.white;

  /// Shimmer base color for dark themes
  static const Color shimmerBase = Color(0xFF2C1D33);

  /// Shimmer highlight color for dark themes
  static const Color shimmerHighlight = Color(0xFF44304D);

  /// Profile skeleton placeholders
  static const Color skeletonPlaceholder = Color(0xFF2D1F35);

  /// Button loading color
  static const Color buttonLoader = Colors.white;
}
