import 'package:flutter/material.dart';

class NameInputField extends StatelessWidget {
  final TextEditingController? controller;
  final String hintText;

  const NameInputField({
    super.key,
    this.controller,
    this.hintText = 'Enter your full name',
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 56,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: const Color(0xFF8B3FAE).withAlpha(46),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: Colors.white.withAlpha(46), width: 1),
      ),
      child: Row(
        children: [
          const Icon(Icons.person_outline, color: Colors.white70, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: TextField(
              controller: controller,
              style: const TextStyle(color: Colors.white, fontSize: 14),
              decoration: InputDecoration(
                isDense: true,
                hintText: hintText,
                hintStyle: const TextStyle(color: Colors.white60),
                border: InputBorder.none,
                contentPadding: EdgeInsets.zero,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
